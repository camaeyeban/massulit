<?php
class Product_Model extends CI_Model {

    private  $table = 'product';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function insert_entry($data)
    {

        $this->db->insert('product', $data);
    }
}
?>
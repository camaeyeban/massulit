<!doctype html>
<html>
<head>
    <link rel="icon" href="http:/massulit/assets/images/icon.jpg">
<meta charset="utf-8">
<title>Registration Page</title>
	
		<link href="http:/massulit/assets/css/bootstrap.css" rel="stylesheet">
		<link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container">
  <form class="form-horizontal">
      <h2>Registration Form</h2>
      <fieldset>
        <legend>Account Details</legend>
        <div class="form-group col-lg-12">
            <label for="inputUsermail" class="col-lg-4 control-label">E-mail Address</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserEmail" placeholder="E-mail Address" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
          <label for="inputPassword1" class="col-lg-4 control-label">Password</label>
          <div class="col-lg-8">
            <input type="password" class="form-control" id="inputPassword1" placeholder="Password">
          </div>
        </div>
        <div class="form-group col-lg-12">
          <label for="inputPassword2" class="col-lg-4 control-label">Confirm Password</label>
          <div class="col-lg-8">
            <input type="password" class="form-control" id="inputPassword2" placeholder="Password">
          </div>
        </div>
      </fieldset>
      <fieldset>
        <legend>Personal Information</legend>
        <div class="form-group col-lg-12">
            <label for="inputUserFName" class="col-lg-4 control-label">First Name</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserFName" placeholder="First Name" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserLName" class="col-lg-4 control-label">Last Name</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserLName" placeholder="Last Name" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserAge" class="col-lg-4 control-label">Age</label>
            <div class="col-lg-8">
                <input type="number" class="form-control" id="inputUserAge" min="18" placeholder="Age" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserBirthdate" class="col-lg-4 control-label">Birthday</label>
            <div class="col-lg-8">
                <input type="date" class="form-control" id="inputUserBirthdate" placeholder="YYYY/MM/DD" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserContact" class="col-lg-4 control-label">Contact Number</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserContact" pattern="[0][0-9]{10}" placeholder="Cellphone Number (09XXXXXXXXX)" required>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserGender" class="col-lg-4 control-label">Gender</label>
            <div class="col-lg-8 radio">
                <label>
                    <input type="radio" name="inputUserGender" id="inputUserGender_1" value="option1" required>Male
                </label>
                <label>
                    <input type="radio" name="inputUserGender" id="inputUserGender_0" value="option2">Female
                </label>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserHomeAddress" class="col-lg-4 control-label">Home Address</label>
            <div class="col-lg-8">
                <textarea name="homeAddress" class="form-control" rows="3" id="inputUserHomeAddress" required></textarea>
            </div>
        </div>
        <div class="form-group col-lg-12">
            <label for="inputUserDelivAddress" class="col-lg-4 control-label">Delivery Address</label>
            <div class="col-lg-8">
                <textarea name="deliveryAddress" class="form-control" rows="3" id="inputUserDelivAddress" required></textarea>
            </div>
        </div>
    </fieldset>
    <fieldset>
      <legend>Payment information</legend>
      <div class="form-group col-lg-12">
          <label for="inputUserCardType" class="col-lg-4 control-label">Card Type</label>
          <div class="col-lg-8">
              <select class="form-control" id="inputUserCardType">
                <option value="amex">American Express</option>
                <option value="master">Master Card</option>
                <option value="visa">Visa</option>
              </select>
          </div>
      </div>
      <div class="form-group col-lg-12">
            <label for="inputUserCardNo" class="col-lg-4 control-label">Card Number</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserCardNo" placeholder="XXXXXXXXXXXXXX" required>
            </div>
      </div>
      <div class="form-group col-lg-12">
        <label for="inputUserCardExpiry" class="col-lg-4 control-label">Card Expiration Date</label>
        <div class="col-lg-8">
            <input type="date" class="form-control" id="inputUserCardExpiry" placeholder="YYYY/MM/DD" required>
        </div>
      </div>
      <div class="form-group col-lg-12">
            <label for="inputUserCardName" class="col-lg-4 control-label">Card Account Name</label>
            <div class="col-lg-8">
                <input type="text" class="form-control" id="inputUserCardName" placeholder="Full Name" required>
            </div>
      </div>
      <div class="form-group col-lg-12">
          <label for="inputUserCardAddress" class="col-lg-4 control-label">Billing Address</label>
          <div class="col-lg-8">
              <textarea name="cardAddress" class="form-control" rows="3" id="inputUserCardAddress" required></textarea>
          </div>
      </div>
    </fieldset>
    <div class="form-group col-lg-12">
      <div class="col-lg-8 col-lg-offset-4">
        <div class="checkbox">
          <label>
            <input type="checkbox"> I have agreed and understood the terms and conditions of MasSulit.com
          </label>
        </div><br>
        <button type="submit" class="btn btn-primary">Submit</button>
        <button class="btn btn-default">Cancel</button>
      </div>
    </div>
  </form>
</div>

</body>
</html>

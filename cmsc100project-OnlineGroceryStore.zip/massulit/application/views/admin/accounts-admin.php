<!DOCTYPE html>
<html lang="en">

<head>
        <link rel="icon" href="http:/massulit/assets/images/icon.jpg">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin | Accounts</title>

    <!-- Bootstrap Core CSS -->
    <link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="http:/massulit/assets/css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="http:/massulit/assets/css/plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="http:/massulit/assets/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="http:/massulit/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- customized css -->
    <link href="http:/massulit/assets/css/admin.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="http:/massulit/assets/images/logo.png" height="80px" style="padding: 10px 0px 10px 0px; margin-top: -15px"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li>
                    <a href="../home/logout">
                        <i class="fa fa-user fa-fw"></i></i>
                    </a>
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/index"><i class="fa fa-th-large fa-fw"></i>&nbsp;&nbsp;Summary</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/products"><i class="fa fa-shopping-cart fa-fw"></i>&nbsp;&nbsp;Products</a>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/transactions"><i class="fa fa-book fa-fw"></i>&nbsp;&nbsp;Transactions</a>
                        </li>
                        <li>
                            <a class="active" href="http://localhost/massulit/index.php/admins/accounts_admin"><i class="fa fa-star fa-fw"></i>&nbsp;&nbsp;Administrators</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/accounts_user"><i class="fa fa-heart fa-fw"></i>&nbsp;&nbsp;Users</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Administrator Accounts</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">

                    <!-- Edit Modal -->
                   <?php
                    foreach ($admins as $admin) {
                        echo '<div class="modal fade" id="editModal-'.$admin->user_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Edit Admin Account Details</h4>
                                    </div>
                                    <div class="modal-body">';
                                        echo form_open('admins/updateAdmin');
                                        echo '<form class="form-horizontal">
                                            <fieldset>';
                                                echo form_hidden('inputAdminID', $admin->user_id);
                                                echo '<div class="form-group col-lg-12">
                                                    <label for="inputAdminFName" class="col-lg-4 control-label">First Name</label>
                                                    <div class="col-lg-8">
                                                        <input type="text" class="form-control" id="inputAdminFName" name="inputAdminFName" placeholder="First Name">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminLName" class="col-lg-4 control-label">Last Name</label>
                                                    <div class="col-lg-8">
                                                        <input type="text" class="form-control" id="inputAdminLName" name="inputAdminLName" placeholder="Last Name">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminAge" class="col-lg-4 control-label">Age</label>
                                                    <div class="col-lg-8">
                                                        <input type="number" class="form-control" id="inputAdminAge" name="inputAdminAge" min="18" placeholder="Age">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminBirthdate" class="col-lg-4 control-label">Birthday</label>
                                                    <div class="col-lg-8">
                                                        <input type="date" class="form-control" id="inputAdminBirthdate" name="inputAdminBirthdate" placeholder="YYYY/MM/DD">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminContact" class="col-lg-4 control-label">Contact Number</label>
                                                    <div class="col-lg-8">
                                                        <input type="text" class="form-control" id="inputAdminContact" name="inputAdminContact" pattern="[0][0-9]{10}" placeholder="Cellphone Number (09XXXXXXXXX)">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminGender" class="col-lg-4 control-label">Gender</label>
                                                    <div class="col-lg-8 radio">
                                                        <label>
                                                            <input type="radio" name="inputAdminGender" id="inputAdminGender_1" value="Male">Male
                                                        </label>
                                                        <label>
                                                            <input type="radio" name="inputAdminGender" id="inputAdminGender_0" value="Female">Female
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminUsername" class="col-lg-4 control-label">Account Name</label>
                                                    <div class="col-lg-8">
                                                        <input type="text" class="form-control" id="inputAdminUsername" name="inputAdminUsername" placeholder="Account Name">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminEmail" class="col-lg-4 control-label">E-mail Address</label>
                                                    <div class="col-lg-8">
                                                        <input type="text" class="form-control" id="inputAdminEmail" name="inputAdminEmail" placeholder="E-mail Address">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminPassword" class="col-lg-4 control-label">Password</label>
                                                    <div class="col-lg-8">
                                                        <input type="password" class="form-control" id="inputAdminPassword" name="inputAdminPassword" placeholder="Password">
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminHomeAddress" class="col-lg-4 control-label">Home Address</label>
                                                    <div class="col-lg-8">
                                                        <textarea class="form-control" rows="3" id="inputAdminHomeAddress" name="inputAdminHomeAddress"></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <label for="inputAdminDelivAddress" class="col-lg-4 control-label">Delivery Address</label>
                                                    <div class="col-lg-8">
                                                        <textarea class="form-control" rows="3" id="inputAdminDelivAddress" name="inputAdminDelivAddress"></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    <div class="col-lg-4"></div>
                                                    <div class="col-lg-8">
                                                        <button type="submit" class="btn btn-default">Save</button>
                                                        <button type="reset" class="btn btn-default">Clear</button>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </form>';
                                        echo form_close();
                                    echo '</div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>

                                </div>
                            </div>
                        </div>';
                    }
                    ?>
                    <!-- End Edit Modal -->
                    <!-- Delete Modal -->
                     <?php
                        foreach ($admins as $admin) {
                            echo '<div class="modal fade" id="deleteModal-'.$admin->user_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Delete Admin Account</h4>
                                        </div>
                                        <div class="modal-body">';
                                            echo form_open('admins/deleteAdmin');
                                            echo form_hidden('inputAdminID', $admin->user_id);
                                            echo '<p> Are you sure you want to delete the following details?</p>
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Admin ID</th>
                                                        <th>Name</th>
                                                        <th>Age</th>
                                                        <th>Gender</th>
                                                        <th>Contact Number</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <tr>
                                                        <td>'. $admin->user_id. '</td>
                                                        <td>'. $admin->user_lname. ', ' . $admin->user_fname. '</td>
                                                        <td>'. $admin->user_age. '</td>
                                                        <td>'. $admin->user_gender. '</td>
                                                        <td>'. $admin->user_contact_number. '</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Continue</button>
                                        </div>';
                                        echo form_close();
                                    echo '</div>
                                </div>
                            </div>';
                        }
                    ?>
                    <!-- End Delete Modal -->
                    <!-- Details Modal -->
                    <?php
                        foreach($admins as $admin){
                            echo '<div class="modal fade" id="detailsModal-'. $admin->user_id. '" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">View Account Details</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table table-hover">
                                                <thead>
                                            <tr>
                                                <th>Admin ID</th>
                                                <th>Name</th>
                                                <th>Age</th>
                                                <th>Gender</th>
                                                <th>Contact Number</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                                <td>'. $admin->user_id. '</td>
                                                <td>'. $admin->user_lname. ', ' . $admin->user_fname. '</td>
                                                <td>'. $admin->user_age. '</td>
                                                <td>'. $admin->user_gender. '</td>
                                                <td>'. $admin->user_contact_number. '</td>
                                            </tr>
                                        </tbody>
                                            </table>
                                            <table class="table table-hover">
                                                <thead>
                                            <tr>
                                                <th>Birthday</th>
                                                <th>E-mail Address</th>
                                                <th>Home Address</th>
                                                <th>Delivery Address</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <tr>
                                                <td>'. $admin->user_bday. '</td>
                                                <td>'. $admin->user_email_address. '</td>
                                                <td>'. $admin->user_home_address. '</td>
                                                <td>'. $admin->user_delivery_address. '</td>
                                            </tr>
                                        </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>';

                        }
                    ?>
                    <!-- Details Modal -->

                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#createAdminAccount" aria-controls="createAdminAccount" role="tab" data-toggle="tab">ADD</a></li>
                    <li role="presentation"><a href="#viewAdminAccount" aria-controls="viewAdminAccount" role="tab" data-toggle="tab">VIEW</a></li>
                  </ul>
                  <!-- Tab panes -->
                  <div class="tab-content">
                    <!-- Create Admin Account -->
                    <div role="tabpanel" class="tab-pane active" id="createAdminAccount">
                        <h2>Create Administator Account</h2>
                        <div class="row"><br>
                            <?php echo form_open('admins/insertAdmin'); ?>
                            <form class="form-horizontal">
                                <fieldset>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminFName" class="col-lg-4 control-label">First Name</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputAdminFName" name="inputAdminFName" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminLName" class="col-lg-4 control-label">Last Name</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputAdminLName" name="inputAdminLName" placeholder="Last Name" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminAge" class="col-lg-4 control-label">Age</label>
                                        <div class="col-lg-6">
                                            <input type="number" class="form-control" id="inputAdminAge" name="inputAdminAge" min="18" placeholder="Age" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminBirthdate" class="col-lg-4 control-label">Birthday</label>
                                        <div class="col-lg-6">
                                            <input type="date" class="form-control" id="inputAdminBirthdate" name="inputAdminBirthdate" placeholder="YYYY/MM/DD" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminContact" class="col-lg-4 control-label">Contact Number</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputAdminContact" name="inputAdminContact" pattern="[0][0-9]{10}" placeholder="Cellphone Number (09XXXXXXXXX)" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminGender" class="col-lg-4 control-label">Gender</label>
                                        <div class="col-lg-6 radio">
                                            <label>
                                                <input type="radio" name="inputAdminGender" id="inputAdminGender_1" value="Male" required>Male
                                            </label>
                                            <label>
                                                <input type="radio" name="inputAdminGender" id="inputAdminGender_0" value="Female">Female
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminEmail" class="col-lg-4 control-label">E-mail Address</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputAdminEmail" name="inputAdminEmail" placeholder="E-mail Address" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminUsername" class="col-lg-4 control-label">Account Name</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputAdminUsername" name="inputAdminUsername" placeholder="Account Name" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminPassword" class="col-lg-4 control-label">Password</label>
                                        <div class="col-lg-6">
                                            <input type="password" class="form-control" id="inputAdminPassword" name="inputAdminPassword" placeholder="Password" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminHomeAddress" class="col-lg-4 control-label">Home Address</label>
                                        <div class="col-lg-6">
                                            <textarea name="inputAdminHomeAddress" class="form-control" rows="3" id="inputAdminHomeAddress" required></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputAdminDelivAddress" class="col-lg-4 control-label">Delivery Address</label>
                                        <div class="col-lg-6">
                                            <textarea name="inputAdminDelivAddress" class="form-control" rows="3" id="inputAdminDelivAddress" required></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <div class="col-lg-4"></div>
                                        <div class="col-lg-6">
                                            <button type="submit" class="btn btn-default">Add</button>
                                            <button type="reset" class="btn btn-default">Clear</button>
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    <!-- End Create Admin Account-->

                    <!-- View Admin Account -->
                    <div role="tabpanel" class="tab-pane" id="viewAdminAccount">
                        <h2>Administrator Account List</h2>
                        <div class="panel-body col-lg-12">
                            <div class="table-responsive col-lg-12">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>User ID</th>
                                            <th>Name</th>
                                            <th>Age</th>
                                            <th>Gender</th>
                                            <th>Contact Number</th>
                                            <th>Birthday</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            foreach($admins as $admin){

                                                echo '<tr>';
                                                echo '<td>' . $admin->user_id . '</td>';
                                                echo '<td>' . $admin->user_lname . ', ' . $admin->user_fname .'</td>';
                                                echo '<td>' . $admin->user_age . '</td>';
                                                echo '<td>' . $admin->user_gender . '</td>';
                                                echo '<td>' . $admin->user_contact_number . '</td>';
                                                echo '<td>' . $admin->user_bday . '</td>';
                                                echo '<td>';
                                                    echo '<button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#editModal-'.$admin->user_id.'">Edit</button>&nbsp;';
                                                    echo '<button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal-'.$admin->user_id.'">Delete</button>&nbsp;';
                                                    echo '<button type="button" class="btn btn-xs btn-info" data-toggle="modal" data-target="#detailsModal-'.$admin->user_id.'">More Details</button>&nbsp;';
                                                echo '</td>';
                                                echo '</tr>';
                                               
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- End View Admin Account -->
                </div>
            </div>
            <!-- tab panel -->

                </div> <!-- Row -->      
        </div> <!-- /#page-wrapper -->

    </div> <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="http:/massulit/assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="http:/massulit/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="http:/massulit/assets/js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="http:/massulit/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="http:/massulit/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="http:/massulit/assets/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>

</body>

</html>

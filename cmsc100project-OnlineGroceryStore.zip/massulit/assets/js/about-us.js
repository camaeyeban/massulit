$(document).ready(function(){
  $($('div.initHide')).hide();//set hide as default
  
  //toggle between hide and show
  $("#show").click(function(){
	$("div.initHide").toggle("slow");
  });
});
	
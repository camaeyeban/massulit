		<div id="footer">
			<p>
				Copyright &copy; 2014. MasSulit.com Online Market. <br>
				Site maintained by UPLB's CMSC 100 EF-3L Markabogable.exe members.<br>
				<a href="http:/massulit/assets/terms-and-conditions.pdf">Terms and Conditions</a>
			</p>
		</div>

		<script src="http:/massulit/assets/js/jquery-1.11.1.min.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.min.js"></script>
		<script src="http:/massulit/assets/js/docs.min.js"></script>
		<script src="http:/massulit/assets/js/ie10-viewport-bug-workaround.js"></script>
	
	</body>
	
</html>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Clients extends CI_Controller {

	public function index()
	{
		$this->load->view('client/home-log');
	}
	
	public function aboutuslog()
	{
		$this->load->view('client/about-us-log');
	}
	
	public function contactuslog()
	{
		$this->load->view('client/contact-us-log');
	}
	
	public function featuredproductslog()
	{
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_featured', TRUE);
			$query = $this->db->get();
			$data['productItem'] = $query->result();

		$this->load->view('client/featured-products-log', $data);
	}
		public function bakerylog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Bakery");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/bakery-log', $data);
		}

		public function meatlog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Meat");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/meat-log', $data);
		}

		public function poultrylog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Poultry");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/poultry-log', $data);
		}

		public function beveragelog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			//$this->db->select('*');
			$this->db->from('product');
			$this->db->where('product_category', "Beverage");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/beverage-log', $data);
		}

		public function dairylog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Dairy");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/dairy-log', $data);
		}

		public function delicacieslog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Delicacies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/delicacies-log', $data);
		}

		public function fruitslog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Fruits");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/fruits-log', $data);
		}

		public function householdsupplieslog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Household Supplies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/household-supplies-log', $data);
		}

		public function schoolsupplieslog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "School Supplies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/school-supplies-log', $data);
		}

		public function seafoodlog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Seafood");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/seafood-log', $data);
		}

		public function vegetableslog(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Vegetables");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('client/vegetables-log', $data);
		}

		public function search(){
			$this->load->helper('form');
			
			$a  = $this->input->post('srch-term');
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			if($a != "all products") $this->db->like('product_name', $a);
			$query = $this->db->get();
			$data['searchResult'] = $query->result();

			$this->load->view('client/search', $data);
		}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
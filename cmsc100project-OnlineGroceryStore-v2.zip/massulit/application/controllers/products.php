<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Products extends CI_Controller {
		public function index(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_featured', TRUE);
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('featured-products', $data);
		}

		public function product(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_featured', TRUE);
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('product', $data);
		}

		public function bakery(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Bakery");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('bakery', $data);
		}

		public function meat(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Meat");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('meat', $data);
		}

		public function poultry(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Poultry");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('poultry', $data);
		}

		public function beverage(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			//$this->db->select('*');
			$this->db->from('product');
			$this->db->where('product_category', "Beverage");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('beverage', $data);
		}

		public function dairy(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Dairy");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('dairy', $data);
		}

		public function delicacies(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Delicacies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('delicacies', $data);
		}

		public function fruits(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Fruits");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('fruits', $data);
		}

		public function householdsupplies(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Household Supplies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('household-supplies', $data);
		}

		public function schoolsupplies(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "School Supplies");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('school-supplies', $data);
		}

		public function seafood(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Seafood");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('seafood', $data);
		}

		public function vegetables(){
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			$this->db->where('product_category', "Vegetables");
			$query = $this->db->get();
			$data['productItem'] = $query->result();

			$this->load->view('vegetables', $data);
		}

		public function search(){
			$this->load->helper('form');

			$a  = $this->input->post('srch-term');
			$this->db->select('product_id, product_name, product_stock, product_price, product_description, product_manufacturing_date, product_expiration_date, product_imageaddr');
			$this->db->from('product');
			if($a != "all products") $this->db->like('product_name', $a);
			$query = $this->db->get();
			$data['searchResult'] = $query->result();
			$this->load->view('search', $data);
		}
	}

?>
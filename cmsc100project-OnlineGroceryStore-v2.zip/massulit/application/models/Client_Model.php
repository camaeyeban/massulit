<?php
class Admin_Model extends CI_Model {

    private  $table = 'product';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function insert_product_bought($data)
    {
        $this->db->insert('product_bought', $data);
    }

}
?>
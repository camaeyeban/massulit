<!DOCTYPE html>
<html lang="en">

<head>

        <link rel="icon" href="http:/massulit/assets/images/icon.jpg">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin | Transactions</title>

    <!-- Bootstrap Core CSS -->
    <link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="http:/massulit/assets/css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="http:/massulit/assets/css/plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="http:/massulit/assets/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="http:/massulit/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- customized css -->
    <link href="http:/massulit/assets/css/admin.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="http:/massulit/assets/images/logo.png" height="80px" style="padding: 10px 0px 10px 0px; margin-top: -15px"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="../home/logout">
                        <i class="fa fa-user fa-fw"></i></i>
                    </a>
                </li>
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       <li>
                            <a href="http://localhost/massulit/index.php/admins/index"><i class="fa fa-th-large fa-fw"></i>&nbsp;&nbsp;Summary</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/products"><i class="fa fa-shopping-cart fa-fw"></i>&nbsp;&nbsp;Products</a>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a class="active" href="http://localhost/massulit/index.php/admins/transactions"><i class="fa fa-book fa-fw"></i>&nbsp;&nbsp;Transactions</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/accounts_admin"><i class="fa fa-star fa-fw"></i>&nbsp;&nbsp;Administrators</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/accounts_user"><i class="fa fa-heart fa-fw"></i>&nbsp;&nbsp;Users</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>



        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Transactions</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- Row -->
            <div class="row">
                <!-- Tab panel -->
                <div class="col-lg-12">

                    <!-- Details Modal -->
                    <?php
                        foreach ($transactions as $row) {
                            echo '<div class="modal fade" id="detailsModal-' . $row->transaction_id . '" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">View Product Details</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Description</th>
                                                        <th># Stocks</th>
                                                        <th>Price</th>
                                                        <th>Manufacturing Date</th>
                                                        <th>Expiration Date</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                            foreach($bought as $item){
                                if($row->transaction_id == $item->transaction_id){
                                    foreach ($products as $product) {
                                        if($item->product_id == $product->product_id){
                                            echo '<tr>';
                                                echo '<td>' . $product->product_id . '</td>';
                                                echo '<td>' . $product->product_name . '</td>';
                                                echo '<td>' . $product->product_description . '</td>';
                                                echo '<td>' . $product->product_stock . '</td>';
                                                echo '<td>' . $product->product_price . '</td>';
                                                echo '<td>' . $product->product_manufacturing_date . '</td>';
                                                echo '<td>' . $product->product_expiration_date . '</td>';
                                            echo '</tr>';
                                        }
                                    }
                                }
                            }       
                                                echo '</tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                        }
                    
                    ?>
                    <!-- Details Modal -->

                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#viewTrans" aria-controls="viewTrans" role="tab" data-toggle="tab">VIEW</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <!-- View Tab -->
                        <div role="tabpanel" class="tab-pane active" id="viewTrans">
                            <h2>Transaction List</h2>
                            <div class="table-responsive row col-lg-12">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Customer Name</th>
                                            <th>Date</th>
                                            <th>Total Items</th>
                                            <th>Total Amount</th>
                                            <th>Item Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                            foreach($transactions as $row){

                                                foreach($buyers as $customer){
                                                    if($row->user_id == $customer->user_id){
                                                        break;
                                                    }
                                                }

                                                echo '<tr>';
                                                echo '<td>' . $row->transaction_id . '</td>';
                                                echo '<td>' . $customer->user_lname . ', ' . $customer->user_fname . '</td>';
                                                echo '<td>' . $row->datetime . '</td>';
                                                echo '<td>' . $row->total_quantity . '</td>';
                                                echo '<td>' . $row->total_amount . '</td>';
                                                echo '<td>';
                                                    echo '<button type="button" class="btn btn-xs btn-info" data-toggle="modal" data-target="#detailsModal-'.$row->transaction_id.'">View Details</button>&nbsp;';
                                                echo '</td>';
                                                echo '</tr>';
                                               
                                            }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- End View Tab -->
                    </div>

                </div>
                <!-- End Tab panel -->

            </div> 
            <!-- Row -->      
        </div> 
        <!-- /#page-wrapper -->

    </div> <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="http:/massulit/assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="http:/massulit/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="http:/massulit/assets/js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="http:/massulit/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="http:/massulit/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="http:/massulit/assets/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>

</body>

</html>

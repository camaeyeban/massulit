<!DOCTYPE html>
<html lang="en">

<head>

        <link rel="icon" href="http:/massulit/assets/images/icon.jpg">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin | Products</title>

    <!-- Bootstrap Core CSS -->
    <link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="http:/massulit/assets/css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="http:/massulit/assets/css/plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="http:/massulit/assets/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="http:/massulit/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- customized css -->
    <link href="http:/massulit/assets/css/admin.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="http:/massulit/assets/images/logo.png" height="80px" style="padding: 10px 0px 10px 0px; margin-top: -15px"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="../home/logout">
                        <i class="fa fa-user fa-fw"></i></i>
                    </a>
                </li>
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/index"><i class="fa fa-th-large fa-fw"></i>&nbsp;&nbsp;Summary</a>
                        </li>
                        <li>
                            <a class="active" href="http://localhost/massulit/index.php/admins/products"><i class="fa fa-shopping-cart fa-fw"></i>&nbsp;&nbsp;Products</a>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/transactions"><i class="fa fa-book fa-fw"></i>&nbsp;&nbsp;Transactions</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/accounts_admin"><i class="fa fa-star fa-fw"></i>&nbsp;&nbsp;Administrators</a>
                        </li>
                        <li>
                            <a href="http://localhost/massulit/index.php/admins/accounts_user"><i class="fa fa-heart fa-fw"></i>&nbsp;&nbsp;Users</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Products</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">

                    <!-- Edit Modal -->
                    <?php
                        foreach ($products as $item) {
                            echo '<div class="modal fade" id="editModal-'.$item->product_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Edit Product Details</h4>
                                        </div>
                                        <div class="modal-body">';
                                            echo form_open('admins/updateProduct');
                                            echo '<form class="form-horizontal">
                                                <fieldset>';
                                                    echo form_hidden('inputProdID', $item->product_id );
                                                     echo '<div class="form-group col-lg-10">
                                                        <label for="inputProdName" class="col-lg-4 control-label">Product Name</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" id="inputProdName" name="inputProdName" placeholder="Product Name">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputProductDesc" class="col-lg-4 control-label">Product Description</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" id="inputProductDesc" name="inputProductDesc" placeholder="Product Description">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputStocks" class="col-lg-4 control-label">Product Stocks</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" id="inputStocks" name="inputStocks" placeholder="Product Stocks">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputPrice" class="col-lg-4 control-label">Product Price</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" id="inputPrice" name="inputPrice" placeholder="Product Price">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputManufactureDate" class="col-lg-4 control-label">Manufacturing Date</label>
                                                        <div class="col-lg-6">
                                                            <input type="date" class="form-control" id="inputManufactureDate" name="inputManufactureDate" placeholder="YYYY/MM/DD">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputExpiryDate" class="col-lg-4 control-label">Expiration Date</label>
                                                        <div class="col-lg-6">
                                                            <input type="date" class="form-control" id="inputExpiryDate" name="inputExpiryDate" placeholder="YYYY/MM/DD">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputCategory" class="col-lg-4 control-label">Product Category</label>
                                                        <div class="col-lg-6">
                                                            <select class="form-control" id="inputCategory" name="inputCategory">
                                                                <option value="NULL">-----</option>
                                                                <option value="Bakery">Bakery</option>
                                                                <option value="Beverage">Beverage</option>
                                                                <option value="Dairy">Dairy</option>
                                                                <option value="Delicacies">Delicacies</option>
                                                                <option value="Fruits">Fruits</option>
                                                                <option value="Household Supplies">Household Supplies</option>
                                                                <option value="Meat">Meat</option>
                                                                <option value="Poultry">Poultry</option>
                                                                <option value="School Supplies">School Supplies</option>
                                                                <option value="Seafood">Seafood</option>
                                                                <option value="Vegetables">Vegetables</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <label for="inputExpiryDate" class="col-lg-4 control-label">Image Address</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" id="inputImage" name="inputImage" placeholder="Image Address">
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-lg-10">
                                                        <div class="col-lg-4">
                                                        </div>
                                                        <div class="col-lg-8">
                                                            <input type="checkbox" name="inputFeatured" value="1"> Featured Product?<br><br>
                                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                        </div>
                                                </fieldset>
                                            </form>';
                                            echo form_close();
                                        echo '</div>
                                        <div class="modal-footer">
                                        </div>
                                </div>
                            </div>';
                        }
                    ?>
                    <!-- End of Edit Modals -->
                    <!-- Delete Modal -->
                     <?php
                        foreach ($products as $item) {
                            echo '<div class="modal fade" id="deleteModal-'.$item->product_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Delete Product</h4>
                                        </div>
                                        <div class="modal-body">';
                                            echo form_open('admins/deleteProduct');
                                            echo form_hidden('inputProdID', $item->product_id);
                                            echo '<p> Are you sure you want to delete the following details?</p>
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Product ID</th>
                                                        <th>Name</th>
                                                        <th>Stocks</th>
                                                        <th>Price</th>
                                                        <th>Manufacturing Date</th>
                                                        <th>Expiration Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <tr>
                                                        <td>'. $item->product_id. '</td>
                                                        <td>'. $item->product_name. '</td>
                                                        <td>'. $item->product_stock. '</td>
                                                        <td>'. $item->product_price. '</td>
                                                        <td>'. $item->product_manufacturing_date. '</td>
                                                        <td>'. $item->product_expiration_date. '</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Continue</button>
                                        </div>';
                                        echo form_close();
                                    echo '</div>
                                </div>
                            </div>';
                        }
                    ?>
                    <!-- End Delete Modal -->

                    <!-- Add Stocks Modal -->
                     <?php
                        foreach ($products as $item) {
                            echo '<div class="modal fade" id="stockModal-'.$item->product_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Add Stock on Product</h4>
                                        </div>
                                        <div class="modal-body">';
                                            echo form_open('admins/addStock');
                                            echo form_hidden('inputProdID', $item->product_id);
                                            echo '<div class="form-group col-lg-10">
                                                        <label for="inputStock" class="col-lg-4 control-label">Stock to be added</label>
                                                        <div class="col-lg-6">
                                                            <input type="number" class="form-control" id="inputStock" name="inputStock" placeholder="Stock">
                                                        </div>
                                                    </div><br><br>
                                        </div>
                                        <div class="modal-footer">
                                            <br>
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Continue</button>
                                        </div>';
                                        echo form_close();
                                    echo '</div>
                                </div>
                            </div>';
                        }
                    ?>
                    <!-- End Add Stocks Modal -->

                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#addProd" aria-controls="addProd" role="tab" data-toggle="tab">ADD</a></li>
                    <li role="presentation"><a href="#viewProd" aria-controls="viewProd" role="tab" data-toggle="tab">VIEW</a></li>
                  </ul>
             <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="addProd">
                        <h2>Add Product</h2>
                        <div class="row"><br>
                            <?php echo form_open('admins/insertProduct'); ?>
                            <form class="form-horizontal">
                                <fieldset>
                                     <div class="form-group col-lg-10">
                                        <label for="inputProdName" class="col-lg-4 control-label">Product Name</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputProdName" name="inputProdName" placeholder="Product Name">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputProductDesc" class="col-lg-4 control-label">Product Description</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputProductDesc" name="inputProductDesc" placeholder="Product Description">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputStocks" class="col-lg-4 control-label">Product Stocks</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputStocks" name="inputStocks" placeholder="Product Stocks">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputPrice" class="col-lg-4 control-label">Product Price</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputPrice" name="inputPrice" placeholder="Product Price">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputManufactureDate" class="col-lg-4 control-label">Manufacturing Date</label>
                                        <div class="col-lg-6">
                                            <input type="date" class="form-control" id="inputManufactureDate" name="inputManufactureDate" placeholder="YYYY/MM/DD">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputExpiryDate" class="col-lg-4 control-label">Expiration Date</label>
                                        <div class="col-lg-6">
                                            <input type="date" class="form-control" id="inputExpiryDate" name="inputExpiryDate" placeholder="YYYY/MM/DD">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputCategory" class="col-lg-4 control-label">Product Category</label>
                                        <div class="col-lg-6">
                                            <select class="form-control" id="inputCategory" name="inputCategory">
                                                <option value="NULL">-----</option>
                                                <option value="Bakery">Bakery</option>
                                                <option value="Beverage">Beverage</option>
                                                <option value="Dairy">Dairy</option>
                                                <option value="Delicacies">Delicacies</option>
                                                <option value="Fruits">Fruits</option>
                                                <option value="Household Supplies">Household Supplies</option>
                                                <option value="Meat">Meat</option>
                                                <option value="Poultry">Poultry</option>
                                                <option value="School Supplies">School Supplies</option>
                                                <option value="Seafood">Seafood</option>
                                                <option value="Vegetables">Vegetables</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <label for="inputExpiryDate" class="col-lg-4 control-label">Image Address</label>
                                        <div class="col-lg-6">
                                            <input type="text" class="form-control" id="inputImage" name="inputImage" placeholder="Image Address">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-10">
                                        <div class="col-lg-4"></div>
                                        <div class="col-lg-6">
                                            <input type="checkbox" name="inputFeatured" value="1"> Featured Product?<br><br>
                                            <button type="submit" class="btn btn-default">Add</button>
                                            <button type="reset" class="btn btn-default">Clear</button>
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                            <?php echo form_close(); ?>
                        </div>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="viewProd">
                            <h2>View Product</h2>
                            <div class="panel-body col-lg-12">
                                <div class="table-responsive col-lg-12">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <!--<th>Description</th>-->
                                                <th># Stocks</th>
                                                <th>Price</th>
                                                <th>Manufacturing Date</th>
                                                <th>Expiration Date</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        foreach($products as $items){

                                            echo '<tr>';
                                            echo '<td>' . $items->product_id . '</td>';
                                            echo '<td>' . $items->product_name . '</td>';
                                            //echo '<td>' . $items->product_description . '</td>';
                                            echo '<td>' . $items->product_stock . '</td>';
                                            echo '<td>' . $items->product_price . '</td>';
                                            echo '<td>' . $items->product_manufacturing_date . '</td>';
                                            echo '<td>' . $items->product_expiration_date . '</td>';
                                            echo '<td>';
                                                echo '<button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#editModal-'.$items->product_id.'">Edit</button>&nbsp;';
                                                echo '<button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal-'.$items->product_id.'">Delete</button>';
                                                echo '<button type="button" class="btn btn-xs btn-info" data-toggle="modal" data-target="#stockModal-'.$items->product_id.'">Add Stocks</button>&nbsp;';
                                            echo '</td>';
                                            echo '</tr>';
                                           
                                        }
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <!-- tab panel -->

                </div> <!-- Row -->      
        </div> <!-- /#page-wrapper -->

    </div> <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="http:/massulit/assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="http:/massulit/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="http:/massulit/assets/js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="http:/massulit/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="http:/massulit/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="http:/massulit/assets/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>

</body>

</html>

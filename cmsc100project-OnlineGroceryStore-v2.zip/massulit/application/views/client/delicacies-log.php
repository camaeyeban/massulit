<!DOCTYPE html>
<html lang="en">

	<head>
		<link rel="icon" href="http:/massulit/assets/images/icon.jpg">
		
		<title>MasSulit.com | Products and Services</title>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<link href="http:/massulit/assets/css/home-format.css" rel="stylesheet">
		<link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">
		<script src="http:/massulit/assets/js/ie-emulation-modes-warning.js"></script>
		<link href="http:/massulit/assets/css/home-format.css" rel="stylesheet">
		<script type="text/javascript" src="http:/massulit/assets/js/interact.js" ></script>
        <script type="text/javascript" src="http:/massulit/assets/js/draag.js"></script>
		
		<link href="http:/massulit/assets/css/product.css" rel="stylesheet">
		
	</head>
  
  
	<body>
		<div class="navbar-wrapper">
			<div class="container">

				<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
					<div class="container">
					
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="#">
								<img src="http:/massulit/assets/images/logo.png" height="80px" alt="Second slide" style="padding: 10px 0px 10px 0px;">
							</a>
						</div>
						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav">
								<li><a href="http://localhost/massulit/">Home</a></li>
								<li class="active"><a href="http://localhost/massulit/index.php/welcome/productsandservices">Products and Services</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/aboutus">About Us</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/contactus">Contact Us</a></li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li>
									<form class="navbar-form" role="search" action="http://localhost/massulit/index.php/clients/search" method="post">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">
											<div class="input-group-btn">
												<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
											</div>
										</div>
									</form>
								</li>
								<li><a href="http://localhost/massulit/index.php/home/logout">Logout</a>
							</ul>
						</div>
					</div>
				</nav>
			

			</div>
		</div>

		
		<div class="products-and-services container-fluid">
			<div class="row">
				<div class="col-sm-2 col-md-2 sidebar">					
					<ul class="nav nav-sidebar">
						<li><a href="http://localhost/massulit/index.php/clients/featuredproductslog">Featured Products</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/bakerylog">Bakery</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/meatlog">Meat</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/poultrylog">Poultry</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/seafoodlog">Seafood</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/fruitslog">Fruits</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/vegetableslog">Vegetables</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/dairylog">Dairy</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/beveragelog">Beverage</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/householdsupplieslog">Household Supplies</a></li>
						<li><a href="http://localhost/massulit/index.php/clients/schoolsupplieslog">School Supplies</a></li>
						<li class="active"><a href="http://localhost/massulit/index.php/clients/delicacieslog">Delicacies</a></li>
					</ul>
				</div>
				
				<?php
				foreach ($productItem as $items) {
					echo '<div class="modal fade" id="modal-'.$items->product_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
										<span class="modal-title" id="modalTitle-'.$items->product_id.'">'.$items->product_name.'</span>
									</div>
									<div class="modal-body">
										<table>
											<td>
												<img src="'.$items->product_imageaddr.'" class="pop-up-product-image" alt="Generic placeholder thumbnail"><br>
											</td>
											<td class="desc">
												<span class="bold-title">Price: </span> Php '.$items->product_price.' <br>
												<span class="bold-title">Stock: </span> '.$items->product_stock.' <br>
												<span class="bold-title">Description: </span> '.$items->product_description.' <br>
												<span class="bold-title">Manufacturing Date: </span> '.$items->product_manufacturing_date.' <br>
												<span class="bold-title">Expiration Date: </span> '.$items->product_expiration_date.' <br>
											</td>
										</table>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<input type="number" class="stock-number" max="'.$items->product_stock.'" min="1" placeholder="Quantity">
										<a href="#" data-toggle="modal" data-target="#qty"><button type="submit" class="btn btn-primary">Buy</button></a>
									</div>
								</div>
							</div>
						</div>';
				}
				 
				?>
				
				<div class="col-sm-8 col-md-8 main">
				<?php
					$count = 0;
					$len = count($productItem);
					foreach($productItem as $items){
						if($count % 5 == 0 || $count == 0){
							echo '<div class="row placeholders">';
						}
						echo '<div class="col-xs-6 col-sm-2">';
						echo '<div id="holder"><div  id="yes-drop" class="draggable drag-drop"><a class="placeholder" data-toggle="modal" data-target="#modal-'.$items->product_id.'"><img src="'.$items->product_imageaddr.'" class="img-responsive" alt="Generic placeholder thumbnail"></a></div></div>
						<h4>'. $items->product_name .'</h4>';
						echo '</div>';

						if($count % 5 == 4 || $count == $len - 1){
							echo '</div>';
						}
					
						$count++;
					}
					echo '</div>';
				?>

				<div id="toBack" class="col-sm-2 col-md-offset-2 sidebar1">
					<table class="cart">
						<th class="cart">Product</th>
						<th class="cart">Quantity</th>
						<th class="cart">Price</th>
						<tr>
							<td class="cart-col1">Banana</td>
							<td class="cart-col2">4</td>
							<td class="cart-col3">P 40.00</td>
						</tr>
						<tr>
							<td class="cart-col1">Burger Buns</td>
							<td class="cart-col2">1</td>
							<td class="cart-col3">P 20.00</td>
						</tr>
						<tr>
							<td class="cart-col1">Wilkins</td>
							<td class="cart-col2">2</td>
							<td class="cart-col3">P 28.50</td>
						</tr>
						<tr>
							<td class="cart-col1">Nestle Yogurt</td>
							<td class="cart-col2">1</td>
							<td class="cart-col3">P 25.20</td>
						</tr>
						<tr> 
							<td> <hr> </td>
							<td> <hr> </td>
							<td> <hr> </td>
						</tr>
						<tr>
							<td class="cart-col1" id="total">Total:</td>
							<td class="cart-col2" id="total">8</td>
							<td class="cart-col3" id="total">P 113.70</td>
						</tr>
					</table>
					<br>
					<button class="btn btn-lg btn-primary btn-block buy-button" type="submit">Buy</button>
					<div id="outer-dropzone" class="dropzone">
					<!--  <img src="http:/massulit/assets/images/cart2.png" class="top">
					<div id="inner-dropzone" class="dropzone">#inner-dropzone</div>-->
					</div>
				</div>
			</div>
		</div>
		
		<div id="footer">
			<p>
				Copyright &copy; 2014. MasSulit.com Online Market. <br>
				Site maintained by UPLB's CMSC 100 EF-3L Markabogable.exe members.<br>
				<a href="http:/massulit/assets/terms-and-conditions.pdf">Terms and Conditions</a>
			</p>
		</div>	

		<script src="http:/massulit/assets/js/jquery-1.11.1.min.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.min.js"></script>
		<script src="http:/massulit/assets/js/docs.min.js"></script>
		<script src="http:/massulit/assets/js/ie10-viewport-bug-workaround.js"></script>
		<script src="http:/massulit/assets/js/ie-emulation-modes-warning.js"></script>

	</body>
	
</html>
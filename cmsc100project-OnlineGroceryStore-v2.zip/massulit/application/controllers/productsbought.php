<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class VerifyLogin extends CI_Controller {

 function __construct()
 {
   parent::__construct();
 }

 function index()
 {
   //This method will have the credentials validation
   $this -> db -> select('User_session_id, User_account, User_password');
   $this -> db -> from('user');
   $this -> db -> where('User_account', $username);
   $this -> db -> where('User_password', $password);
   $this -> db -> where('User_isadmin', $isadmin);
   $this -> db -> limit(1);
   if($this->form_validation->run() == FALSE)
   {
     //Field validation failed.  User redirected to login page
     $this->load->view('sign-in', 'refresh');
   }
   else
   {
     //Go to private area
	 $this->load->view('client/home-log');
	
   }

 }

}
?>
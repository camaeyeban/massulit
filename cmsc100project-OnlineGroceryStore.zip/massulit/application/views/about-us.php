<!DOCTYPE html>
<html lang="en">

	<head>
		<link rel="icon" href="http:/massulit/assets/images/icon.jpg">
		
		<title>MasSulit.com | About Us</title>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<link href="http:/massulit/assets/css/about-us-format.css" rel="stylesheet">
		<link href="http:/massulit/assets/css/home-format.css" rel="stylesheet">
		<link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">
		<script src="http:/massulit/assets/js/ie-emulation-modes-warning.js"></script>
		<link href="http:/massulit/assets/css/home-format.css" rel="stylesheet">
	</head>
  
  
	<body>
		<div class="navbar-wrapper">
			<div class="container">

				<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
					<div class="container">
					
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="#">
								<img src="http:/massulit/assets/images/logo.png" height="80px" alt="Second slide" style="padding: 10px 0px 10px 0px;">
							</a>
						</div>
						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav">
								<li><a href="http://localhost/massulit/">Home</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/productsandservices">Products and Services</a></li>
								<li class="active"><a href="http://localhost/massulit/index.php/welcome/aboutus">About Us</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/contactus">Contact Us</a></li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li><a href="#" data-toggle="collapse" data-target="#userlogin">User Log-in</a></li>
								<li><a href="#" data-toggle="collapse" data-target="#adminlogin">Admin Log-in</a></li>
							</ul>
						</div>
					</div>
				</nav>
			
				<div id="userlogin" class="panel panel-default panel-login collapse">
					<div class="panel-body">
						<?php echo validation_errors(); ?>
						<?php echo form_open('verifylogin'); ?>
							<h4 class="form-signin-heading">Sign in to MasSulit</h4>
							<br>
							<input name="username" id="username" class="form-control" placeholder="Username" required autofocus>
							<br>
							<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
							<div class="checkbox">
								<label>
								<input type="checkbox" value="remember-me"> Remember me
								</label>
							</div>
							<br>
							<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
						</form>
					</div>
				</div>

				<div id="adminlogin" class="panel panel-default panel-login collapse">
					<div class="panel-body">
						<?php echo validation_errors(); ?>
						<?php echo form_open('verifyloginadmin'); ?>
							<h4 class="form-signin-heading">Sign in to MasSulit</h4>
							<br>
							<input name="username" id="username" class="form-control" placeholder="Username" required autofocus>
							<br>
							<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
							<div class="checkbox">
								<label>
								<input type="checkbox" value="remember-me"> Remember me
								</label>
							</div>
							<br>
							<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
						</form>
					</div>
				</div>

			</div>
		</div>

		
		<div class="about-us-container">
			<table class="about-us-table">
				<td class="col1">
				<div class="about-us-header">About Us</div>
					<p class="text-justify">In a very technological world that we live in, almost everything is achieved by a click of a button.   We can pay bills; Reserve plane or bus tickets; Talk or chat with friends and loved ones; Watch concerts in the comforts of your own home; We can even shop online.</p>
					<p>MasSulit.com is an online grocery store that allows you to order and buy your groceries via the internet.  Just click the products that you want and voila!  Easy right?  Yes. We make it our upmost priority to put make sure that your needs are met.  So what are you waiting for?  Come on!  Your needs are <b>JUST A CLICK AWAY</b>.</p>
				
				<div class="subcontainer">
					<div class="about-us-subheader">Mission</div>
					<p>To provide high quality yet affordable products and a convenient way of shopping through offering an online grocery store that helps customers save time, compute expenses and conserve energy.</p>
				</div>
				<div class="subcontainer">
					<div class="about-us-subheader">Vision</div>
					<p>To implement a hassle-free and time-saving service through an online grocery store</p>
				</div>

				<div class="about-us-subheader meet">Meet the Team</div>
					<p>Providing good service is never easy.  It takes a lot time, effort, dedication (and sweat, blood and sleepless nights).  Our team makes a point of providing quality service just for you.  Meet the people behind it all.</p>
					<p>Markabogable.exe is a group of Third Year students taking B.S. Computer Science at the University of the Philippines Los Ba&ntilde;os.   This site is the result of their group project for CMSC100 (Section EF-3L, A.Y. 2014-2015).</p><br>
					<p>Click the button below to see the list of the members of Markabogable.exe and some of their personal information.</p>
					<div class="col-md-4"></div>
					<div class="col-md-4">
					<center><button class="btn btn-lg btn-primary btn-block" id="show" title="Click to show/hide">MARKABOGABLE.EXE</button></center>
					<div class="col-md-4"></div>
					</div>
					<br><br>

				<div class="initHide">
					<div class="row">
						<div class="col-md-6">
							<center><img src="http:/massulit/assets/images/about-us/carl.jpg" class="img-circle img-thumbnail name-image"></center>
							<h5 class="about-us-name">Carl Jaylord P. Tagle</h5>
							<p class="names">
							<b>EMAIL:</b> fcjptagle@gmail.com<br>
							<b>MOBILE NO:</b> 09165900924/09193930492<br>
							<b>CAMPUS ADDRESS:</b> Casa Francisco, Dinorado cor. Milagrosa St. Batong Malake, Los Ba&ntilde;os 4031, Laguna<br>
							<b>HOME ADDRESS:</b> Block 1 Lot 10 Daang Bakal St., Burgos, Rodriguez, Rizal<br>
							</p>
						</div>
						<div class="col-md-6">
							<center><img src="http:/massulit/assets/images/about-us/marion.jpg" class="img-circle img-thumbnail name-image"></center>
							<h5 class="about-us-name">Marion Paulo A. Dagang</h5>
							<p class="names">
							<b>EMAIL:</b> mariondagang@gmail.com<br>
							<b>MOBILE NO:</b> 09363313062<br>
							<b>CAMPUS ADDRESS:</b> Mochang Tahanan Dorm Arayat Street Umali Subdivision Batong Malake, Los Ba&ntilde;os, Laguna<br>
							<b>HOME ADDRESS:</b> Don Onofre Village, Banay Banay, Cabuyao, Laguna<br>
							</p>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<center><img src="http:/massulit/assets/images/about-us/mae.jpg" class="img-circle img-thumbnail name-image"></center>
							<h5 class="about-us-name">Felicia Mae L. Sace</h5>
							<p class="names">
							<b>EMAIL:</b> feliciamaesace@gmail.com<br>
							<b>MOBILE NO:</b> 09496036620<br>
							<b>CAMPUS ADDRESS:</b> Door 8 Perez Apartments, Grove Street, Batong Malake, Los Ba&ntilde;os, Laguna<br>
							<b>HOME ADDRESS:</b> Pinggan, Gasan, Marinduque<br>
							</p>
						</div>
						<div class="col-md-6">
							<center><img src="http:/massulit/assets/images/about-us/mayel.jpg" class="img-circle img-thumbnail name-image"></center>
							<h5 class="about-us-name">Mayrielle Anne A. Bermas</h5>
							<p class="names">
							<b>EMAIL:</b> mabermas@gmail.com<br>
							<b>MOBILE NO:</b> 09166172828/09309261307<br>
							<b>CAMPUS ADDRESS:</b> Women's Residence Hall, UPLB, College, Laguna<br>
							<b>HOME ADDRESS:</b> 7-A 4th st. West Tapinac Olongapo City<br>
							</p>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-3"></div>
						<div class="col-md-6">
							<center><img src="http:/massulit/assets/images/about-us/camae.jpg" class="img-circle img-thumbnail name-image"></center>
							<h5 class="about-us-name">Erica Mae M. Yeban</h5>
							<p class="names">
							<b>EMAIL:</b> camaeyeban@gmail.com<br>
							<b>MOBILE NO:</b> 09057148221<br>
							<b>CAMPUS ADDRESS:</b> 9702 Diamond Street, Umali Subdivision, Batong Malake, Los Ba&ntilde;os, Laguna<br>
							<b>HOME ADDRESS:</b> Brgy. Sta. Cecilia Tagkawayan, Quezon<br>
							</p>
						</div>
					</div>
				</div>
				
				</td>
				<td class="col2">

				</td>
			<table>
		</div>
		
		<div id="footer">
			<p>
				Copyright &copy; 2014. MasSulit.com Online Market. <br>
				Site maintained by UPLB's CMSC 100 EF-3L Markabogable.exe members.<br>
				<a href="http:/massulit/assets/terms-and-conditions.pdf">Terms and Conditions</a>
			</p>
		</div>

		<script src="http:/massulit/assets/js/jquery-1.11.1.min.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.min.js"></script>
		<script src="http:/massulit/assets/js/docs.min.js"></script>
		<script src="http:/massulit/assets/js/ie10-viewport-bug-workaround.js"></script>
		<script src="http:/massulit/assets/js/about-us.js"></script>
	</body>
	
</html>
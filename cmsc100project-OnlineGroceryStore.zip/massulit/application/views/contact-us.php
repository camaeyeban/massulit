<!DOCTYPE html>
<html lang="en">

	<head>
		<link rel="icon" href="http:/massulit/assets/images/icon.jpg">
		
		<title>MasSulit.com | Contact Us</title>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<link href="http:/massulit/assets/css/bootstrap.min.css" rel="stylesheet">
		<script src="http:/massulit/assets/js/ie-emulation-modes-warning.js"></script>
		<link href="http:/massulit/assets/css/home-format.css" rel="stylesheet">
		<link href="http:/massulit/assets/css/contact-us-format.css" rel="stylesheet">
	</head>
  
  
	<body>
		<div class="navbar-wrapper">
			<div class="container">

				<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
					<div class="container">
					
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="#">
								<img src="http:/massulit/assets/images/logo.png" height="80px" alt="Second slide" style="padding: 10px 0px 10px 0px;">
							</a>
						</div>
						<div id="navbar" class="navbar-collapse collapse">
							<ul class="nav navbar-nav">
								<li><a href="http://localhost/massulit/">Home</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/productsandservices">Products and Services</a></li>
								<li><a href="http://localhost/massulit/index.php/welcome/aboutus">About Us</a></li>
								<li class="active"><a href="http://localhost/massulit/index.php/welcome/contactus">Contact Us</a></li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li><a href="#" data-toggle="collapse" data-target="#userlogin">User Log-in</a></li>
								<li><a href="#" data-toggle="collapse" data-target="#adminlogin">Admin Log-in</a></li>
							</ul>
						</div>
					</div>
				</nav>
				
				<div id="userlogin" class="panel panel-default panel-login collapse">
					<div class="panel-body">
						<?php echo validation_errors(); ?>
						<?php echo form_open('verifylogin'); ?>
							<h4 class="form-signin-heading">Sign in to MasSulit</h4>
							<br>
							<input name="username" id="username" class="form-control" placeholder="Username" required autofocus>
							<br>
							<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
							<div class="checkbox">
								<label>
								<input type="checkbox" value="remember-me"> Remember me
								</label>
							</div>
							<br>
							<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
						</form>
					</div>
				</div>

				<div id="adminlogin" class="panel panel-default panel-login collapse">
					<div class="panel-body">
						<?php echo validation_errors(); ?>
						<?php echo form_open('verifyloginadmin'); ?>
							<h4 class="form-signin-heading">Sign in to MasSulit</h4>
							<br>
							<input name="username" id="username" class="form-control" placeholder="Username" required autofocus>
							<br>
							<input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
							<div class="checkbox">
								<label>
								<input type="checkbox" value="remember-me"> Remember me
								</label>
							</div>
							<br>
							<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
						</form>
					</div>
				</div>
				
				
			</div>
		</div>

		
		<div class="contact-us-container">
			<table class="contact-us-table">
				<td class="col1">
					<form class="form-signin" role="form">
						<div class="contact-us-form-header">Contact Us</div>
						<br>
						<p>
							<b>We are looking forward to hearing from you!</b>
						</p>Name:
						<input type="name" class="form-control" required autofocus>
						<br>Email address:
						<input type="email" class="form-control" required>
						<br>Message:
						<textarea rows="6" class="form-control" required> </textarea>
						<br>
						<button class="btn btn-lg btn-primary btn-block contact-us-button" type="submit">Submit</button>
					</form>
				</td>
				<td class="col2">
					<div class="contact-us-subheader"> Contact Details:
					</div><br>
					<label>
						<img src="http:/massulit/assets/images/contact-us/telephone-image.png">
						123-456
					</label> <br>
					<label>
						<img src="http:/massulit/assets/images/contact-us/message-image.png">
						masSulit@gmail.com
					</label> <br>
					<label>
						<img src="http:/massulit/assets/images/contact-us/facebook-image.png">
						massulitdotcom
					</label> <br>
					<label>
						<img src="http:/massulit/assets/images/contact-us/instagram-image.png">
						massulitdotcom
					</label> <br>
					<label>
						<img src="http:/massulit/assets/images/contact-us/twitter-image.png">
						massulitdotcom
					</label> <br>
				</td>
			<table>
		</div>
		
		
		<div id="footer">
			<p>
				Copyright &copy; 2014. MasSulit.com Online Market. <br>
				Site maintained by UPLB's CMSC 100 EF-3L Markabogable.exe members.<br>
				<a href="http:/massulit/assets/terms-and-conditions.pdf">Terms and Conditions</a>
			</p>
		</div>

		<script src="http:/massulit/assets/js/jquery-1.11.1.min.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.js"></script>
		<script src="http:/massulit/assets/js/bootstrap.min.js"></script>
		<script src="http:/massulit/assets/js/docs.min.js"></script>
		<script src="http:/massulit/assets/js/ie10-viewport-bug-workaround.js"></script>
	
	</body>
	
</html>
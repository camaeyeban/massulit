<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Admins extends CI_Controller {
		public function index(){
			$this->db->select('transaction_id, total_quantity, total_amount, user_id, datetime');
			$this->db->from('transaction');
			$query1 = $this->db->get();
			$data['transactions'] = $query1->result();

			$this->db->select('user_id, user_lname, user_fname, user_account, user_password, user_email_address, user_home_address, user_delivery_address, user_contact_number, user_gender, user_bday, user_age');
			$this->db->from('user');
			$this->db->where('user_isadmin', FALSE);
			$query2 = $this->db->get();
			$data['buyers'] = $query2->result();

			$this->db->select('product_id, product_name, product_description, product_stock, product_price, product_manufacturing_date, product_expiration_date');
			$this->db->from('product');
			$query3 = $this->db->get();
			$data['products'] = $query3->result();

			$this->db->select('user_id, user_lname, user_fname, user_account, user_password, user_email_address, user_home_address, user_delivery_address, user_contact_number, user_gender, user_bday, user_age');
			$this->db->from('user');
			$this->db->where('user_isadmin', TRUE);
			$query4 = $this->db->get();
			$data['admins'] = $query4->result();

			$this->load->view('admin/index', $data);
		}

		public function products(){
			$this->db->select('product_id, product_name, product_description, product_stock, product_price, product_manufacturing_date, product_expiration_date');
			$this->db->from('product');
			$query = $this->db->get();
			$data['products'] = $query->result();

			$this->load->view('admin/products', $data);

		}

		public function transactions(){
			$this->db->select('transaction_id, total_quantity, total_amount, user_id, datetime');
			$this->db->from('transaction');
			$query1 = $this->db->get();
			$data['transactions'] = $query1->result();

			$this->db->select('user_id, user_lname, user_fname, user_account, user_password, user_email_address, user_home_address, user_delivery_address, user_contact_number, user_gender, user_bday, user_age');
			$this->db->from('user');
			$this->db->where('user_isadmin', FALSE);
			$query2 = $this->db->get();
			$data['buyers'] = $query2->result();

			$this->db->select('product_id, product_name, product_description, product_stock, product_price, product_manufacturing_date, product_expiration_date');
			$this->db->from('product');
			$query3 = $this->db->get();
			$data['products'] = $query3->result();

			$this->db->select('transaction_id, product_id, quantity_per_product, amount_per_product');
			$this->db->from('product_bought');
			$query4 = $this->db->get();
			$data['bought'] = $query4->result();

			$this->load->view('admin/transactions', $data);
		}

		public function accounts_admin(){
			$this->db->select('user_id, user_lname, user_fname, user_account, user_password, user_email_address, user_home_address, user_delivery_address, user_contact_number, user_gender, user_bday, user_age');
			$this->db->from('user');
			$this->db->where('user_isadmin', TRUE);
			$query = $this->db->get();
			$data['admins'] = $query->result();

			$this->load->view('admin/accounts-admin', $data);
		}

		public function accounts_user(){
			$this->db->select('user_id, user_lname, user_fname, user_account, user_password, user_email_address, user_home_address, user_delivery_address, user_contact_number, user_gender, user_bday, user_age');
			$this->db->from('user');
			$this->db->where('user_isadmin', FALSE);
			$query = $this->db->get();
			$data['users'] = $query->result();

			$this->load->view('admin/accounts-user', $data);
		}

		public function logs_admin(){
			$this->load->view('admin/logs-admin');
		}

		public function logs_user(){
			$this->load->view('admin/logs-user');
		}

		public function addStock(){
			$id = $this->input->post('inputProdID');
	        $stocks = $this->input->post('inputStock');

			$this->db->select('product_stock');
			$this->db->from('product');
			$this->db->where('product_id', $id);
			$query = $this->db->get();

			foreach ($query->result() as $result) {
				$stocks = $stocks + $result->product_stock;
			}

			$details = array(
	            'product_stock' => $stocks,
	        );

			$this->db->where('product_id', $id);
			$this->db->update('product', $details);

			$this->products();

		}

		public function insertProduct(){
		    $this->load->model('Admin_Model');
		
	        $name = $this->input->post('inputProdName');
	        $description = $this->input->post('inputProductDesc');
	        $stocks = $this->input->post('inputStocks');
	        $price = $this->input->post('inputPrice');
	        $manDate = $this->input->post('inputManufactureDate');
	        $expDate = $this->input->post('inputExpiryDate');
	        $category = $this->input->post('inputCategory');
	        $featured = $this->input->post('inputFeatured');
	        $imageAddress = $this->input->post('inputImage');

	        $details = array(
	            'product_name' => $name,
	            'product_description' => $description,
	            'product_stock' => $stocks,
	            'product_price' => $price,
	            'product_manufacturing_date' => $manDate,
	            'product_expiration_date' => $expDate,
	            'product_category' => $category,
	            'product_featured' => $featured,
	            'product_imageaddr' => $imageAddress
	        );

			// Transfering Data To Model
			$this->Admin_Model->insert_product($details);
			// Loading View
			$this->products();
		}

		public function updateProduct(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputProdID');
		    $name = $this->input->post('inputProdName');
	        $description = $this->input->post('inputProductDesc');
	        $stocks = $this->input->post('inputStocks');
	        $price = $this->input->post('inputPrice');
	        $manDate = $this->input->post('inputManufactureDate');
	        $expDate = $this->input->post('inputExpiryDate');

	        $details = array(
	            'product_name' => $name,
	            'product_description' => $description,
	            'product_stock' => $stocks,
	            'product_price' => $price,
	            'product_manufacturing_date' => $manDate,
	            'product_expiration_date' => $expDate
	        );

			$this->db->where('product_id', $id);
			$this->db->update('product', $details); 

			// Loading View
			$this->products();
		}

		public function deleteProduct(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputProdID');

			$this->db->delete('product', array('product_id' => $id));
			
			// Loading View
			$this->products();
		}

		public function insertAdmin(){
		    $this->load->model('Admin_Model');
		
	        $fname = $this->input->post('inputAdminFName');
	        $lname = $this->input->post('inputAdminLName');
	        $age = $this->input->post('inputAdminAge');
	        $birthday = $this->input->post('inputAdminBirthdate');
	        $contact = $this->input->post('inputAdminContact');
	        $gender = $this->input->post('inputAdminGender');
	        $email = $this->input->post('inputAdminEmail');
	        $username = $this->input->post('inputAdminUsername');
	        $password = $this->input->post('inputAdminPassword');
	        $homeAdd = $this->input->post('inputAdminHomeAddress');
	        $delAdd = $this->input->post('inputAdminDelivAddress');

	        $details = array(
	            'user_fname' => $fname,
	            'user_lname' => $lname,
	            'user_account' => $age,
	            'user_account' => $username,
	            'user_password' => $password,
	            'user_email_address' => $email,
	            'user_home_address' => $homeAdd,
	            'user_delivery_address' => $delAdd,
	            'user_contact_number' => $contact,
	            'user_gender' => $gender,
	            'user_bday' => $birthday,
	            'user_age' => $age,
	            'user_isadmin' => TRUE
	        );

			// Transfering Data To Model
			$this->Admin_Model->insert_admin($details);
			// Loading View
			$this->accounts_admin();
		}

		public function updateAdmin(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputAdminID');
			if($this->input->post('inputAdminFName')){
				$fname = $this->input->post('inputAdminFName');
				$details['user_fname'] = $fname;
			}
			if($this->input->post('inputAdminLName')){
				$lname = $this->input->post('inputAdminLName');
				$details['user_lname'] = $lname;
			}
			if($this->input->post('inputAdminAge')){
				$age = $this->input->post('inputAdminAge');
				$details['user_age'] = $age;
			}
			if($this->input->post('inputAdminBirthdate')){
				$birthday = $this->input->post('inputAdminBirthdate');
				$details['user_bday'] = $birthday;
			}
			if($this->input->post('inputAdminContact')){
				$contact = $this->input->post('inputAdminContact');
				$details['user_contact_number'] = $contact;
			}
			if($this->input->post('inputAdminGender')){
				$gender = $this->input->post('inputAdminGender');
				$details['user_gender'] = $gender;
			}
			if($this->input->post('inputAdminEmail')){
				$email = $this->input->post('inputAdminEmail');
				$details['user_email_address'] = $email;
			}
			if($this->input->post('inputAdminUsername')){
				$username = $this->input->post('inputAdminUsername');
				$details['user_account'] = $username;
			}
			if($this->input->post('inputAdminPassword')){
				$password = $this->input->post('inputAdminPassword');
				$details['user_password'] = $password;
			}
			if($this->input->post('inputAdminHomeAddress')){
				$homeAdd = $this->input->post('inputAdminHomeAddress');
				$details['user_home_address'] = $homeAdd;
			}
			if($this->input->post('inputAdminDelivAddress')){
				$delAdd = $this->input->post('inputAdminDelivAddress');
				$details['user_delivery_address'] = $delAdd;
			}

			$this->db->where('user_id', $id);
			$this->db->update('user', $details); 

			// Loading View
			$this->accounts_admin();
		}

		public function deleteAdmin(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputAdminID');

			$this->db->delete('user', array('user_id' => $id));
			
			// Loading View
			$this->accounts_admin();
		}

		public function insertUser(){
		    $this->load->model('Admin_Model');
		
	        $fname = $this->input->post('inputUserFName');
	        $lname = $this->input->post('inputUserLName');
	        $age = $this->input->post('inputUserAge');
	        $birthday = $this->input->post('inputUserBirthdate');
	        $contact = $this->input->post('inputUserContact');
	        $gender = $this->input->post('inputUserGender');
	        $email = $this->input->post('inputUserEmail');
	        $username = $this->input->post('inputUserUsername');
	        $password = $this->input->post('inputUserPassword');
	        $homeAdd = $this->input->post('inputUserHomeAddress');
	        $delAdd = $this->input->post('inputUserDelivAddress');

	        $details = array(
	            'user_fname' => $fname,
	            'user_lname' => $lname,
	            'user_account' => $age,
	            'user_account' => $username,
	            'user_password' => $password,
	            'user_email_address' => $email,
	            'user_home_address' => $homeAdd,
	            'user_delivery_address' => $delAdd,
	            'user_contact_number' => $contact,
	            'user_gender' => $gender,
	            'user_bday' => $birthday,
	            'user_age' => $age,
	            'user_isadmin' => FALSE
	        );

			// Transfering Data To Model
			$this->Admin_Model->insert_user($details);
			// Loading View
			$this->accounts_admin();
		}

		public function updateUser(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputAdminID');
			if($this->input->post('inputAdminFName')){
				$fname = $this->input->post('inputAdminFName');
				$details['user_fname'] = $fname;
			}
			if($this->input->post('inputAdminLName')){
				$lname = $this->input->post('inputAdminLName');
				$details['user_lname'] = $lname;
			}
			if($this->input->post('inputAdminAge')){
				$age = $this->input->post('inputAdminAge');
				$details['user_age'] = $age;
			}
			if($this->input->post('inputAdminBirthdate')){
				$birthday = $this->input->post('inputAdminBirthdate');
				$details['user_bday'] = $birthday;
			}
			if($this->input->post('inputAdminContact')){
				$contact = $this->input->post('inputAdminContact');
				$details['user_contact_number'] = $contact;
			}
			if($this->input->post('inputAdminGender')){
				$gender = $this->input->post('inputAdminGender');
				$details['user_gender'] = $gender;
			}
			if($this->input->post('inputAdminEmail')){
				$email = $this->input->post('inputAdminEmail');
				$details['user_email_address'] = $email;
			}
			if($this->input->post('inputAdminUsername')){
				$username = $this->input->post('inputAdminUsername');
				$details['user_account'] = $username;
			}
			if($this->input->post('inputAdminPassword')){
				$password = $this->input->post('inputAdminPassword');
				$details['user_password'] = $password;
			}
			if($this->input->post('inputAdminHomeAddress')){
				$homeAdd = $this->input->post('inputAdminHomeAddress');
				$details['user_home_address'] = $homeAdd;
			}
			if($this->input->post('inputAdminDelivAddress')){
				$delAdd = $this->input->post('inputAdminDelivAddress');
				$details['user_delivery_address'] = $delAdd;
			}

			$this->db->where('user_id', $id);
			$this->db->update('user', $details); 

			// Loading View
			$this->accounts_admin();
		}

		public function deleteUser(){
		    $this->load->model('Admin_Model');

		    $id = $this->input->post('inputUserID');

			$this->db->delete('user', array('user_id' => $id));
			
			// Loading View
			$this->accounts_user();
		}

	}
?>